<?php
header("Location: login.html");
exit;

require_once 'config.php';
?>